import 'bootstrap/dist/css/bootstrap.css';
require('bootstrap');