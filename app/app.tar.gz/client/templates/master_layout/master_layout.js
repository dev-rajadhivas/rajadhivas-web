Template.MasterLayout.helpers({
});

Template.MasterLayout.events({
});
