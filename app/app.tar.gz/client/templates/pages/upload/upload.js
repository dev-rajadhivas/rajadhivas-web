



/***********************************************************	******************/
/* Upload: Event Handlers */
/*****************************************************************************/
Template.Upload.events({ 

	'click .create': function(e) {
    
        $('#myModalLabel').text('เพิ่มข้อมูล');
        $('.save_changes').show();
        clearInput('value_upload');
        $('.imagepreview').attr('src','');
        $('#myModal').modal("show");
        $('.save_changes').attr('data-check','insertupload');
    },

     'click .btnEdit': function(e) {
        $('#myModalLabel').text('แก้ไขข้อมูล');
        $('.save_changes').show();
        var _id = $(e.target).attr('_id');
        console.log('_id', _id);
        $('#myModal').modal('show');       
        $('.save_changes').attr('data-check','updateupload');
        $('.save_changes').attr('data-upload', _id);
        var queryupload = Upload.findOne({ _id:  _id });
        $('#droplist').val(queryupload.droplist);
        $('#topic').val(queryupload.topic);
        $('#content').val(queryupload.content);
        $('.imagepreview').attr('src',queryupload.img);

    },

      'click .btnDelete': function(e) {
        
        var _id = $(e.target).attr('_id');
         var alertdialog = confirm("คุณต้องการลบหรือไม่");
    	if (alertdialog == true) {
        	Meteor.call('deleteupload', _id ,function(e,result){
			if (e) {

			}else{

			}
		});
    	}
	},


	
	'click .save_changes':function(e){
		
		
	var droplist = $('#droplist').val();
    var topic = $('#topic').val();
    var content = $('#content').val();
    var img = $('.imagepreview').attr('src')
  

    moment.locale('th');
    var date = moment().locale('th').format('LL');
    var time = moment().locale('th').format('LT');
    var _id = $(e.target).attr('data-upload');
    var check = $(e.target).attr('data-check');
    console.log(check);

    if (check == 'insertupload') {
            Meteor.call('insertupload', droplist, topic, content, img, date, time , function(error, result) {
                if (error) {
                    alert('เกิดข้อผิดพลาด');    
                } else {
                    $('#myModal').modal('hide');
                }
            })
        } else {
            Meteor.call('updateupload', _id, droplist, topic, content, img, date, time,  function(error, result) {
                if (error) {
                    alert("เกิดข้ อผิดพลาด");
						
                } else {
                	
                    $('#myModal').modal('hide');
                    

                }
            })
        }


  
    
    
    // Meteor.call('couch_test');
  },

  


});

/*****************************************************************************/
/* Upload: Helpers */
/*****************************************************************************/
Template.Upload.helpers({

 Upload : function () {
	 	console.log(Upload.find().fetch());
      return Upload.find().fetch();
    },
	tableSettings : function () {
      return {
      	rowsPerPage: 10,
      	showFilter: true,
        fields: [
        	{ key: 'droplist', label: 'ประเภท' },
            { key: 'topic', label: 'หัวข้อ' },
            
            { key: 'content', label: 'เนื้อหา' },
            { key: 'date', label: 'วันที่' },
            { key: 'time', label: 'เวลา' },
            { key: '_id', label: 'Edit', 

                fn : function (val, type, doc) { 
                      return Spacebars.SafeString('<button type="button" class="btn btnEdit btn-warning" _id='+ val +' "><i class="fa fa-pencil-square-o" aria-hidden="true"></i></button> <button type="button"  class="btn btnDelete btn-danger" _id='+ val +'><i class="fa fa-trash-o" aria-hidden="true"></i></button>') 
                  } 

            },
          ]
      };
    }

});

/*****************************************************************************/
/* Upload: Lifecycle Hooks */
/*****************************************************************************/
Template.Upload.onCreated(function () {
	Meteor.subscribe('Upload');
});

Template.Upload.onRendered(function () {
});

Template.Upload.onDestroyed(function () {
});
