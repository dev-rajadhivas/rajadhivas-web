/*****************************************************************************/
/* Garage: Event Handlers */
/*****************************************************************************/
Template.Garage.events({

  'click .create': function(e) {
    
        $('#myModalLabel').text('เพิ่มข้อมูล');
        $('.save_changes').show();
        clearInput('value_garage');
        $('.imagepreview').attr('src','');
        $('#myModal').modal("show");
        $('.save_changes').attr('data-check','insertgarage');

        


    },

  'click .btnEdit': function(e) {
        $('#myModalLabel').text('แก้ไขข้อมูล');
        $('.save_changes').show();
        var _id = $(e.target).attr('_id');
        console.log('_id', _id);
        
        $('#myModal').modal('show');
        
        $('.save_changes').attr('data-check','updategarage');
        $('.save_changes').attr('data-garage', _id);
        var querygarage = Garage.findOne({ _id:  _id });
        $('#name_garage').val(querygarage.name_garage);
        $('#long_ti').val(querygarage.long_ti);
        $('#la_ti').val(querygarage.la_ti);
        console.log(querygarage)
        $('.imagepreview').attr('src',querygarage.img);

    },


    'click .btnDelete': function(e) {
        
        var _id = $(e.target).attr('_id');
         var alertdialog = confirm("คุณต้องการลบหรือไม่");
    	if (alertdialog == true) {
        	Meteor.call('deletegarage', _id ,function(e,result){
			if (e) {

			}else{

			}
		});
    	}
	},


    

  'click .save_changes':function(e){
    
    var name_garage = $('#name_garage').val();
    var long_ti = $('#long_ti').val();
    var la_ti = $('#la_ti').val();
    var img = $('.imagepreview').attr('src')
  

    moment.locale('th');
    var date = moment().locale('th').format('LL');
    var time = moment().locale('th').format('LT');
    var _id = $(e.target).attr('data-garage');
    var check = $(e.target).attr('data-check');
    console.log(check);

    if (check == 'insertgarage') {
            Meteor.call('insertgarage', name_garage, long_ti, la_ti, img, date,time, function(error, result) {
                if (error) {
                    alert('เกิดข้อผิดพลาด');    
                } else {
                    $('#myModal').modal('hide');
                }
            })
        } else {
            Meteor.call('updategarage', _id, name_garage, long_ti, la_ti, img,  function(error, result) {
                if (error) {
                    alert("เกิดข้ อผิดพลาด");
						
                } else {
                	
                    $('#myModal').modal('hide');
                    

                }
            })
        }


  
    
    
    // Meteor.call('couch_test');
  },

  


});

/*****************************************************************************/
/* Garage: Helpers */
/*****************************************************************************/
Template.Garage.helpers({


 Garage : function () {
	 	console.log(Garage.find().fetch());
      return Garage.find().fetch();
    },

	tableSettings : function () {
      return {
      	rowsPerPage: 10,
      	showFilter: true,
        fields: [
            { key: 'name_garage', label: 'สาขา' },
            { key: 'long_ti', label: 'Longitude' },
            { key: 'la_ti', label: 'Latitude' },
            { key: '_id', label: 'Edit', 

                fn : function (val, type, doc) { 
                      return Spacebars.SafeString('<button type="button" class="btn btnEdit btn-warning" _id='+ val +' "><i class="fa fa-pencil-square-o" aria-hidden="true"></i></button> <button type="button"  class="btn btnDelete btn-danger" _id='+ val +'><i class="fa fa-trash-o" aria-hidden="true"></i></button>') 
                  } 

            },
          ]
      };
    }




});

/*****************************************************************************/
/* Garage: Lifecycle Hooks */
/*****************************************************************************/
Template.Garage.onCreated(function () {

Meteor.subscribe('Garage');


});

Template.Garage.onRendered(function () {
});

Template.Garage.onDestroyed(function () {
});
