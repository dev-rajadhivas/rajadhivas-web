/*****************************************************************************/
/* Userprofile: Event Handlers */
/*****************************************************************************/
Template.Userprofile.events({
});

/*****************************************************************************/
/* Userprofile: Helpers */
/*****************************************************************************/
Template.Userprofile.helpers({
});

/*****************************************************************************/
/* Userprofile: Lifecycle Hooks */
/*****************************************************************************/
Template.Userprofile.onCreated(function () {
});

Template.Userprofile.onRendered(function () {
});

Template.Userprofile.onDestroyed(function () {
});
