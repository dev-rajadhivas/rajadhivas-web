Meteor.publish('Menu', function() {
    return Menu.find();
});

Meteor.publish('Stock', function() {
    return Stock.find();
});

Meteor.publish('Upload', function() {
    return Upload.find();
});

Meteor.publish('Garage', function() {
    return Garage.find();
});