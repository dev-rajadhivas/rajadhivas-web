Meteor.methods({
    'insertupload': function(droplist, topic, content, img, date,time) {
        
        console.log("crete")
        Upload.insert({
            "droplist" : droplist, 
            "topic" : topic, 
            "content" : content, 
            "date" : date,
            "time" : time,
            "img" : img,
            
            
        })
    },




    'updateupload': function(_id, droplist, topic, content, img, date,time) {
        
        Upload.update({ _id:_id,
                droplist : droplist, 
                topic : topic, 
                content : content, 
                img : img,
                date : date,
                time : time,
        })

    },


    'deleteupload': function(_id) {
        console.log("delete")
        Upload.remove({ _id:_id, })

    },

  

});



