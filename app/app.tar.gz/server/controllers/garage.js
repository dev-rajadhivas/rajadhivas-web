Meteor.methods({
    'insertgarage': function(name_garage, long_ti, la_ti, img, date,time) {
        
        console.log("crete")
        Garage.insert({
            "name_garage" : name_garage, 
            "long_ti" : long_ti, 
            "la_ti" : la_ti, 
            "date" : date,
            "time" : time,
            "img" : img,
            
            
        })
    },




    'updategarage': function(_id, name_garage, long_ti, la_ti, img) {
        console.log('_id',_id);
        console.log('name_garage',name_garage);
        console.log('long_ti',long_ti);
        console.log('la_ti',la_ti);
        console.log('img',img);
        Garage.update({ _id:_id,
                name_garage : name_garage, 
                long_ti : long_ti, 
                la_ti : la_ti, 
                img : img,
        })

    },


    'deletegarage': function(_id) {
        console.log("delete")
        Garage.remove({ _id:_id, })

    },

  

});



