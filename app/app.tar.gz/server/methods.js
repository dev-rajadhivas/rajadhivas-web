/*****************************************************************************/
/*  Server Methods */
/*****************************************************************************/

Meteor.methods({
  'couch_test': function () {
  	var test = Menu.find();
  	console.log("data" ,test.fetch());
    return test;
  }
});
